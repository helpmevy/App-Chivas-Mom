/* Service worker: lưu sẵn file để app chạy offline.
   Khi sửa code, đổi số phiên bản CACHE (v1 -> v2) để điện thoại cập nhật. */
const CACHE = 'mechivas-v2';
const FILES = ['./', 'index.html', 'style.css', 'app.js', 'data.js', 'manifest.json',
  'lib/html2canvas.min.js', 'lib/jspdf.umd.min.js',
  'icons/icon-180.png', 'icons/icon-192.png', 'icons/icon-512.png'];
self.addEventListener('install', e => { e.waitUntil(caches.open(CACHE).then(c => c.addAll(FILES))); self.skipWaiting(); });
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== CACHE).map(k => caches.delete(k)))));
  self.clients.claim();
});
self.addEventListener('fetch', e => {
  if (e.request.method !== 'GET') return;
  e.respondWith(caches.match(e.request, { ignoreSearch: true }).then(r => r || fetch(e.request)));
});
